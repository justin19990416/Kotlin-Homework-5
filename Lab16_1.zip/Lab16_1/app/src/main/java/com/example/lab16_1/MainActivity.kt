package com.example.lab16_1

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var items: ArrayList<String> = ArrayList()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var dbrw: SQLiteDatabase

    // 1. 將 UI 元件宣告為全域變數，避免重複查找
    private lateinit var edBook: EditText
    private lateinit var edPrice: EditText
    private lateinit var btnInsert: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button
    private lateinit var btnQuery: Button
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 2. 初始化 UI 元件 (只做一次)
        initViews()

        // 取得資料庫實體
        dbrw = MyDBHelper(this).writableDatabase

        // 宣告Adapter並連結ListView
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        // 設定監聽器
        setListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        dbrw.close() // 關閉資料庫
    }

    private fun initViews() {
        edBook = findViewById(R.id.edBook)
        edPrice = findViewById(R.id.edPrice)
        btnInsert = findViewById(R.id.btnInsert)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnDelete = findViewById(R.id.btnDelete)
        btnQuery = findViewById(R.id.btnQuery)
        listView = findViewById(R.id.listView)
    }

    private fun setListener() {
        // --- 新增功能 ---
        btnInsert.setOnClickListener {
            if (edBook.text.isEmpty() || edPrice.text.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                try {
                    // 3. 使用參數化查詢 (arrayOf) 防止 SQL Injection
                    dbrw.execSQL(
                        "INSERT INTO myTable(book, price) VALUES(?,?)",
                        arrayOf(edBook.text.toString(), edPrice.text.toString())
                    )
                    showToast("新增:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("新增失敗:$e")
                }
            }
        }

        // --- 修改功能 ---
        btnUpdate.setOnClickListener {
            if (edBook.text.isEmpty() || edPrice.text.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                try {
                    // 優化：使用 WHERE book = ? 確保精確修改，並使用參數傳遞數值
                    dbrw.execSQL(
                        "UPDATE myTable SET price = ? WHERE book = ?",
                        arrayOf(edPrice.text.toString(), edBook.text.toString())
                    )
                    showToast("更新:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("更新失敗:$e")
                }
            }
        }

        // --- 刪除功能 ---
        btnDelete.setOnClickListener {
            if (edBook.text.isEmpty()) {
                showToast("書名請勿留空")
            } else {
                try {
                    // 優化：使用參數化查詢
                    dbrw.execSQL(
                        "DELETE FROM myTable WHERE book = ?",
                        arrayOf(edBook.text.toString())
                    )
                    showToast("刪除:${edBook.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("刪除失敗:$e")
                }
            }
        }

        // --- 查詢功能 ---
        btnQuery.setOnClickListener {
            val queryString = if (edBook.text.isEmpty()) {
                "SELECT * FROM myTable"
            } else {
                "SELECT * FROM myTable WHERE book = ?"
            }

            // 4. 設定查詢參數，若無書名則為 null
            val args = if (edBook.text.isEmpty()) null else arrayOf(edBook.text.toString())

            val c = dbrw.rawQuery(queryString, args)

            items.clear()
            showToast("共有${c.count}筆資料")

            // 5. 使用標準的 Cursor 遍歷方式
            c.moveToFirst()
            for (i in 0 until c.count) {
                // 使用索引讀取資料 (0=book, 1=price)，並加入 List
                items.add("書名:${c.getString(0)}\t\t\t\t價格:${c.getInt(1)}")
                c.moveToNext()
            }

            adapter.notifyDataSetChanged()
            c.close() // 務必關閉 Cursor
        }
    }

    private fun showToast(text: String) =
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show() // 改為 SHORT 讓體驗更流暢

    private fun cleanEditText() {
        edBook.setText("")
        edPrice.setText("")
    }
}

//安全性升級 (防止 SQL Injection) ：



//改前："WHERE book LIKE '${edBook.text}'"。這種字串串接方式非常危險，如果輸入包含特殊符號，可能會導致資料庫被攻擊或程式崩潰。

//修改後：使用 ? 作為佔位符，並配合 arrayOf(...) 傳入參數。例如 dbrw.execSQL(..., arrayOf(name))。這讓系統自動處理特殊字元，更加安全。

//效能優化 (View Lookup)：

//修改前：每次按下按鈕或執行 cleanEditText 時，都會重新呼叫 findViewById。

//修改後：將 EditText 和 Button 提升為類別層級變數，並在 onCreate (透過 initViews) 只查找一次。這樣可以減少資源消耗。

//邏輯精確度：

//修改前：Update 和 Delete 使用 LIKE。LIKE 通常用於模糊搜尋。

//修改後：改用 =。當你要刪除或修改特定書籍時，應該要精確對應書名，避免誤刪除名稱相似的書。

//Kotlin 語法慣例：

//使用 isEmpty() 取代 length < 1，語意更清晰。

//Toast 時間改為 LENGTH_SHORT，對於這種頻繁的操作回饋，短時間顯示體驗較佳。