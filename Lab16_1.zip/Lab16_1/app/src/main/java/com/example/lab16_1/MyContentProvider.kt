package com.example.lab16_1

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri

class MyContentProvider : ContentProvider() {
    private lateinit var dbrw: SQLiteDatabase

    companion object {
        // 定義常數，避免手打字串出錯
        private const val TABLE_NAME = "myTable"
        private const val COL_BOOK = "book"
    }

    override fun onCreate(): Boolean {
        val context = context ?: return false
        // 取得資料庫實體
        dbrw = MyDBHelper(context).writableDatabase
        return true
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        // 取出要新增的資料，若為 null 則直接返回
        val bookValues = values ?: return null

        // 將資料新增於資料庫並回傳此筆紀錄的 Id
        val rowId = dbrw.insert(TABLE_NAME, null, bookValues)

        // 若新增失敗 (rowId = -1)，則回傳 null
        if (rowId == -1L) return null

        // 優化：使用 ContentUris 工具來產生回傳的 Uri，比字串串接更安全標準
        // 這會產生類似 content://com.example.lab16/1 的 Uri
        return ContentUris.withAppendedId(uri, rowId)
    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        // selection 參數在這裡被當作「書名」使用
        val name = selection ?: return 0
        val priceValues = values ?: return 0

        // 優化：使用參數化查詢 (WHERE book = ?)，並透過 selectionArgs 傳入書名
        // 這能防止 SQL Injection，並處理特殊字元
        return dbrw.update(TABLE_NAME, priceValues, "$COL_BOOK = ?", arrayOf(name))
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        // selection 參數在這裡被當作「書名」使用
        val name = selection ?: return 0

        // 優化：同樣使用參數化查詢來刪除資料
        return dbrw.delete(TABLE_NAME, "$COL_BOOK = ?", arrayOf(name))
    }

    override fun query(
        uri: Uri, projection: Array<String>?, selection: String?,
        selectionArgs: Array<String>?, sortOrder: String?
    ): Cursor? {
        // selection 參數在這裡被當作「書名」使用
        // 如果 selection 為 null，表示查詢全部；否則查詢特定書名
        val selectionClause = if (selection == null) null else "$COL_BOOK = ?"
        val args = if (selection == null) null else arrayOf(selection)

        // 優化：將 SQL 語法與參數分離
        return dbrw.query(TABLE_NAME, null, selectionClause, args, null, null, null)
    }

    override fun getType(uri: Uri): String? = null
}
/*
安全性升級 (防止 SQL Injection)：

修改前："book='${name}'"。這種字串串接容易出錯且不安全。

修改後："$COL_BOOK = ?", arrayOf(name)。使用 ? 作為佔位符，並將實際數值透過參數陣列傳入，這是 SQLite 操作的標準安全寫法。

標準化 URI 建構：

修改前：Uri.parse("content://com.example.lab16/$rowId")。寫死字串容易在 Package 名稱變更時失效。

修改後：ContentUris.withAppendedId(uri, rowId)。這是 Android 提供的標準方法，它會自動基於傳入的 uri 加上 ID，更具彈性。

常數提取：

將 "myTable" 和 "book" 提取為 TABLE_NAME 和 COL_BOOK，避免在多個方法中重複手打字串，減少打錯字的風險。

邏輯保持：

這段程式碼維持了原本的特殊邏輯：selection 參數直接被當作「書名」傳遞。雖然在標準 ContentProvider 設計中 selection 通常是 SQL 語法 (如 id=?)，但為了配合你的 Client 端 App ( Lab16_2)，這裡保留了原本的設計意圖，只是將內部實作改為安全版本。*/