package com.example.lab16_1

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// 自訂建構子並繼承 SQLiteOpenHelper 類別 [cite: 543]
class MyDBHelper(
    context: Context,
    name: String = DB_NAME,
    factory: SQLiteDatabase.CursorFactory? = null,
    version: Int = VERSION
) : SQLiteOpenHelper(context, name, factory, version) {

    companion object {
        private const val DB_NAME = "myDatabase" // 資料庫名稱
        private const val VERSION = 1            // 資料庫版本

        // 優化重點：公開常數
        // 讓 ContentProvider 或 Activity 可以直接引用，不用手打字串
        const val TABLE_NAME = "myTable"
        const val COL_BOOK = "book"
        const val COL_PRICE = "price"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // 優化重點：使用字串樣板 (String Template) 與常數來建立 SQL
      // 原始邏輯參考: [cite: 552-553]
        val sql = "CREATE TABLE $TABLE_NAME ($COL_BOOK text PRIMARY KEY, $COL_PRICE integer NOT NULL)"
        db.execSQL(sql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // 優化重點：使用常數刪除資料表
     // 原始邏輯參考: [cite: 559]
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
}

//提取公開常數 (const val)：

//原本 myTable, book, price 這些字串散落在 onCreate、onUpgrade，甚至外面的 MyContentProvider 裡。

//改成 const val 後，外部類別可以使用 MyDBHelper.TABLE_NAME 來存取。如果未來要修改欄位名稱，只需要改這裡一行，整個 App 都會自動更新。

//字串樣板 ($Variable)：

//使用 Kotlin 的字串樣板 CREATE TABLE $TABLE_NAME ... 取代傳統的字串拼接，程式碼可讀性更高。

//配合 MyContentProvider 使用：

//如果你採用了這個優化，你的 MyContentProvider 就可以把 private const val TABLE_NAME = "myTable" 拿掉，直接改用 MyDBHelper.TABLE_NAME，這樣程式架構會更緊密且一致。